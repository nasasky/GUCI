<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/24
 * Time: 14:01
 */

namespace app\api\model;


use think\Model;

class OrderProduct extends Model
{

}