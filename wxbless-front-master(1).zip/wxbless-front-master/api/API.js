const api = {
  'home':'https://www.djfans.net/index.php/WxController/',
}
module.exports = api;