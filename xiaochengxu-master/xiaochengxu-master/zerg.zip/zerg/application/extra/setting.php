<?php
/**
 * Created by PhpStorm.
 * User: zhongrc
 * Date: 2018/7/15
 * Time: 16:17
 */

return [
    'img_prefix' => 'http://z.cn/public',
    'token_expire_in' => 7200
];