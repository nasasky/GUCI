exports.app_key = "82422ee2140ce2e87ca84430fa8821f3"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = false; //默认不获取用户坐标位置
exports.appid = "wxd39a70bfffe094cb"; //用于用户登录、微信转发群信息、二维码等微信官方功能
exports.appsecret = "29c82fa253f8711fb010ce5a6b70f019";//用于用户登录、微信转发群信息、二维码等微信官方功能
exports.defaultPath = 'pages/index/index';//小程序的默认首页, 用于分享时path为空时
