<?php
/**
 * Created by PhpStorm.
 * User: zhongrc
 * Date: 2018/7/15
 * Time: 16:17
 */

return [
    'token_salt' => 'abcdefghi',
];