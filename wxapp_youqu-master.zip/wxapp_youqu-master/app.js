App({
  globalData: {
    doubanBase: "https://douban.uieee.com",
    gankBase: "https://gank.io",
    // videoBase:"https://c.3g.163.com"
    videoBase:"http://ph.94xintuo.com"
  }
})  