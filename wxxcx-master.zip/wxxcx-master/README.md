# wxxcx
> 基于wepy构建的一个小程序,整合了n多查询工具,后续逐步更新!

>技术调研了下taro+taro-ui+云开发项目，也已完成发布了，[传送门](https://github.com/wuhou123/taro-card)

# 记录
>  5.14开始编辑,初始版
   
>  8.24完善版,待后期优化
   
>  8.27需求:需要添加国际快递,新闻资讯添加,记录.....

# [体验吧]

![二维码](http://osk1hpe2y.bkt.clouddn.com/18-8-26/87348357.jpg)

# 项目运行
```
微信开发中工具选中wxxcx/dist作为项目目录即可
```

# 功能列表
## 页面
- [x] 国内/国际快递 -- 完成
- [x] 其他信息查询 -- 完成
- [x] 记账本 -- 完成
- [x] 计划 -- 完成
- [x] 摇骰子(加速器仿微信摇一摇) -- 完成
- [x] 生成自定义canvas分享图片 -- 完成
- [x] 幸运测试 -- 完成
- [x] 天气查询 -- 完成
- [x] 计划echarts表 -- 完成
- [x] 账本echarts表 -- 完成
- [x] 自定义顶部导航栏 -- 完成
- [x] 页面自定义分享 -- 完成
- [ ] 界面ui优化 -- 未做
- [ ] 后台 -- 未做



## 组件
- [x] 各个tab页组件
- [x] 功能基本拆分组件


# 效果展示

### 首页分类查询tab页

<img src="http://osk1hpe2y.bkt.clouddn.com/18-9-4/43840176.jpg" width="320" height="619"/>

### 天气查询及今日看点(视频)页

<img src="http://osk1hpe2y.bkt.clouddn.com/18-9-4/44449564.jpg" width="320" height="619"/>

### 我的页面

<img src="http://osk1hpe2y.bkt.clouddn.com/18-9-4/92069905.jpg" width="320" height="619"/>

# 后期需求
```
需要了解node后端,补全后端,也许会更改mpvue方向,期待部署上后台
```

# 说明

>  借鉴了mp-jishengji项目,如果本项目对您有帮助，欢迎 "Star" 支持一下 谢谢~




# 最后

1、欢迎关注我的公众号,[传送门](https://jiashidai.gitee.io/carforwuhou/)





