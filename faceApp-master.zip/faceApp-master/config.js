//百度人脸识别API配置
const APP_ID = "14223078";
const API_KEY = "aLSvUpG7xga2KTtlkuiB9VKe";
const SECRET_KEY = "sG2nLGGRb7u5pVX6X2BrcxxmaGpevz2Y";
const group_id = "ruanyun";



module.exports = {
    APP_ID,
    API_KEY,
    SECRET_KEY,
    group_id
}